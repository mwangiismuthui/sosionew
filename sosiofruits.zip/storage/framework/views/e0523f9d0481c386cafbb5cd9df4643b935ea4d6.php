
			

			<header class="page_header header_darkgrey dark bordered_items">
				<div class="container">
					<div class="row">
						<div class="col-sm-12 text-center">
							<!-- main nav start -->
							<nav class="mainmenu_wrapper">
								<ul class="mainmenu nav sf-menu">
									<li>
                                        <a href="<?php echo e(route('index')); ?>">Home</a>
										</li>

										
									
										<li>
											<a href="<?php echo e(route('order')); ?>">Order Online</a>
										
										</li>
										
										<li>
                                        <a href="<?php echo e(route('about')); ?>">About us</a>

										</li>
										<li>
											<a href="<?php echo e(route('contact')); ?>">Contacts</a>
											
										</li>
								</ul>
							</nav>
							<!-- eof main nav -->
						</div>
					</div>
				</div>
			</header>
<?php /**PATH /home/mwangi/Documents/laravel_projects/clients/sosiofruits/resources/views/layout/header.blade.php ENDPATH**/ ?>