	<!--Start footer-->
	<footer class="footer">
        <div class="container">
          <div class="text-center">
            Copyright © 2020 Iam Motors
          </div>
        </div>
      </footer>
      <!--End footer-->