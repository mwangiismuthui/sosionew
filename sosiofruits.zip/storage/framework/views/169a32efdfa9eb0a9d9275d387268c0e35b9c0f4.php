<div id="sidebar-wrapper" data-simplebar="" data-simplebar-auto-hide="true">
  <div class="brand-logo">
    <a href="<?php echo e(route('dashboard')); ?>">
      <img src="/backend/assets/images/logo.png" class="logo-icon" alt="logo icon">
      <h5 class="logo-text">SosioFruits</h5>
    </a>
  </div>
  <ul class="sidebar-menu do-nicescrol">
    <li class="sidebar-header">MAIN NAVIGATION</li>
    
    <li>
      <a href="<?php echo e(route('dashboard')); ?>" class="waves-effect">
        <i class="ti-home"></i> <span>Dashboard</span>
      </a>

    </li>
    <li>
    <a href="<?php echo e(route('category.index')); ?>" class="waves-effect">
        <i class="ti-shopping-cart"></i>
        <span>Category Management</span>
      </a>

    </li>
    <li>
    <a href="<?php echo e(route('product.index')); ?>" class="waves-effect">
        <i class="ti-shopping-cart"></i>
        <span>Product Management</span>
      </a>

    </li>
  
    <li>
    <a href="<?php echo e(route('slider.index')); ?>" class="waves-effect">
        <i class="ti-shopping-cart"></i>
        <span>Slider Management</span>
      </a>

    </li>
    <li>
    <a href="<?php echo e(route('seo.index')); ?>" class="waves-effect">
        <i class="ti-shopping-cart"></i>
        <span>SEO Management</span>
      </a>

    </li>
 


  </ul>

</div><?php /**PATH /home/mwangi/Documents/laravel_projects/clients/sosiofruits/resources/views/admin/layout/sidebar.blade.php ENDPATH**/ ?>