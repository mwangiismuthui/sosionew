<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="container-fluid">

        <div class="row">
 <div class="col-md-6">
<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <form id="service_add" method="POST" enctype="multipart/form-data" action="<?php echo e(route('category.update',$category->id)); ?>" >
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="title">Category Name</label>
        <input type="text" class="form-control form-control-rounded" id="title"
    placeholder="Enter Category Name" name="category" value="<?php echo e($category->category); ?>">
    </div>


    <div class="form-group">
        <button type="submit" class="btn btn-primary shadow-primary btn-round px-5"><i
                class="icon-checkbox3"></i> Save</button>
    </div>
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

</div>
</div>
<script>

function deletepic(photo_id) {
        $.ajax({
url:'/photo/destroy',
method:'Delete',
data:{
    photo_id:photo_id,
    _token: "<?php echo e(csrf_token()); ?>",
},
success:function(){
location.reload();
},
error:function(){
    console.log('error');

}
        });
        
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mwangi/Documents/laravel_projects/clients/sosiofruits/resources/views/admin/category/edit.blade.php ENDPATH**/ ?>