<?php $__env->startSection('content'); ?>
<div id="wrapper">
    <div class="height-100v d-flex align-items-center justify-content-center">
       <div class="card border-primary border-top-sm border-bottom-sm card-authentication1 mx-auto my-4 animated bounceInDown">
           <div class="card-body">
            <div class="card-content p-2">
                <div class="text-center">
                    <img src="/backend/assets/images/logo.png">
                </div>
             <div class="card-title text-uppercase text-center py-3">Sign Up</div>
             <form method="POST" action="<?php echo e(route('register')); ?>">
                <?php echo csrf_field(); ?>

                 
                 <div class="form-group">
                  <div class="position-relative has-icon-right">
                     <label for="exampleInputName" class="sr-only"> Name</label>
                     <input id="name" type="text" class="form-control form-control-rounded <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus placeholder=" Name">

                     <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                         <span class="invalid-feedback" role="alert">
                             <strong><?php echo e($message); ?></strong>
                         </span>
                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     <div class="form-control-position">
                         <i class="icon-user"></i>
                     </div>
                  </div>
                 </div>
                 <div class="form-group">
                  <div class="position-relative has-icon-right">
                     <label for="exampleInputEmailId" class="sr-only">Email ID</label>
                     <input id="email" type="email" class="form-control form-control-rounded <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" placeholder="Email">

                     <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                         <span class="invalid-feedback" role="alert">
                             <strong><?php echo e($message); ?></strong>
                         </span>
                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     <div class="form-control-position">
                         <i class="icon-envelope-open"></i>
                     </div>
                  </div>
                 </div>
                 <div class="form-group">
                  <div class="position-relative has-icon-right">
                     <label for="exampleInputPassword" class="sr-only">Password</label>
                     <input id="password" type="password" class="form-control form-control-rounded <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password"  placeholder="Password">

                     <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                         <span class="invalid-feedback" role="alert">
                             <strong><?php echo e($message); ?></strong>
                         </span>
                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     <div class="form-control-position">
                         <i class="icon-lock"></i>
                     </div>
                  </div>
                 </div>
                 <div class="form-group">
                  <div class="position-relative has-icon-right">
                     <label for="exampleInputRetryPassword" class="sr-only">Retry Password</label>
                   
                     <input id="password-confirm" type="password" class="form-control form-control-rounded" name="password_confirmation" required autocomplete="new-password" placeholder="Retry Password"/>
                     <div class="form-control-position">
                         <i class="icon-lock"></i>
                     </div>
                  </div>
                 </div>
                <button type="submit" class="btn btn-primary shadow-primary btn-round btn-block waves-effect waves-light">Sign Up</button>
                 <div class="text-center pt-3">
                   
                   
                   <hr>
                   <p class="text-muted mb-0">Already have an account? <a href="<?php echo e(route('login')); ?>"> Sign In here</a></p>
                 </div>
                </form>
              </div>
             </div>
            </div>
            </div>
       
        <!--Start Back To Top Button-->
       <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
       <!--End Back To Top Button-->
       </div><!--wrapper-->
       
     <!-- Bootstrap core JavaScript-->
     <script src="/backend/assets/js/jquery.min.js"></script>
     <script src="/backend/assets/js/popper.min.js"></script>
     <script src="/backend/assets/js/bootstrap.min.js"></script>
     
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mwangi/Documents/laravel_projects/clients/sosiofruits/resources/views/auth/register.blade.php ENDPATH**/ ?>