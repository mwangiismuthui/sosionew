<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
<section class="page_breadcrumbs ds parallax section_padding_top_75 section_padding_bottom_75">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 text-center">
                <ol class="breadcrumb darklinks">
                    <li>
                        <a href="<?php echo e(route('index')); ?>">
                Home
            </a>
                    </li>
                    <li>
                        <a href="javascript:void();">Product</a>
                    </li>
                    <li class="active"><?php echo e($product->product); ?></li>
                </ol>
            </div>
        </div>
    </div>
</section>


<section class="ls section_padding_top_130 section_padding_bottom_130 columns_padding_25">
    <div class="container">
        <div class="row">

            <div class="col-sm-12">


                <div itemscope="" itemtype="" class="product type-product row columns_padding_25">

                    <div class="col-sm-6">
                        <?php $__currentLoopData = $productphotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productphoto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                        <div class="item-media images muted_background text-center rounded overflow_hidden" >

                            <a href="<?php echo e(URL::to('/')); ?>/SosioFruits_Products/<?php echo e($productphoto->pluck('image_path')->first()); ?>" alt="<?php echo e($product->product); ?>" itemprop="image" class="woocommerce-main-image zoom prettyPhoto" data-gal="prettyPhoto[product-gallery]">
                                <img src="<?php echo e(URL::to('/')); ?>/SosioFruits_Products/<?php echo e($productphoto->pluck('image_path')->first()); ?>" alt="<?php echo e($product->product); ?>" class="attachment-shop_single wp-post-image"  id="prodducts-image">
                            </a>

                            <div class="cs main_color2 entry-meta media-meta vertical-center text-center">
                                <div class="price weight-black fontsize_30">
                                    <span>
                                        <span class="amount"><?php echo e($product->product); ?> </span>
                                    </span>
                                </div>
                                <div>
                                   
                                </div>
                            </div>
                        </div>

                        <br><br>
                     
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!--eof .images -->
                   
                        <!-- eof .images -->
                    </div>

                    <div class="summary entry-summary col-sm-6">


                        <h1 itemprop="name" class="product_title "> <?php echo e($product->product); ?></h1>


                        <div style="text-align:justify;">
                            <?php echo $product->description; ?>

                       
                        <a href="<?php echo e(route('order')); ?>" class="theme_button color2">
                          Order <?php echo e($product->product); ?> Now
                        </a>
                        </div>

        

                       

                    </div>
                    <!-- .summary.col- -->

                </div>
                <!-- .product.row -->

                

                <div class="row topmargin_50">
                    <div class="col-sm-12">
                        <h3 class="text-center">Related products</h3>

                        <div class="owl-carousel topmargin_30" data-dots="false" data-loop="true" data-autoplay="true" data-responsive-lg="3">
                 <?php $__currentLoopData = $relateds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <div class="vertical-item product text-center">

                                <div class="item-media bottom-slider-img muted_background rounded overflow_hidden" ">
                                    <a href="<?php echo e(route('product.details',$related->id)); ?>">
                                        <img src="<?php echo e(URL::to('/')); ?>/SosioFruits_Products/<?php echo e($related->productphotos->where('type','main_image')->pluck('image_path')->first()); ?>" alt="<?php echo e($related->product); ?>">
                                    </a>

                                    <div class="cs main_color2 entry-meta media-meta vertical-center text-center">
                                        <div class="price weight-black fontsize_30">
                                            <span>
                                                <span class="amount"><?php echo e($related->product); ?></span>
                                            </span>
                                        </div>
                                        <div>
                                            
                                        </div>
                                    </div>
                                </div>

                          
                            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           

                    


                        </div>
                    </div>
                </div>


            </div>

        </div>
    </div>
</section>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mwangi/Documents/laravel_projects/clients/sosiofruits/resources/views/export/product_details.blade.php ENDPATH**/ ?>